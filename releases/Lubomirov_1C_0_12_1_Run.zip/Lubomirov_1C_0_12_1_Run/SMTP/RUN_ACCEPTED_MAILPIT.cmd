@echo off
setlocal
set "MP_SMTP_FORWARD_CONFIG="
set "MP_SMTP_RELAY_CONFIG="
if not exist "%~dp0RUNS" mkdir "%~dp0RUNS"
:newname
set "VKR_MAIL_DB=%~dp0RUNS\accepted-%RANDOM%-%RANDOM%.db"
if exist "%VKR_MAIL_DB%" goto newname
copy /b "%~dp0mailpit_accepted.db" "%VKR_MAIL_DB%" >nul
if errorlevel 1 goto end
"%~dp0mailpit.exe" --smtp 127.0.0.1:1025 --listen 127.0.0.1:8025 --database "%VKR_MAIL_DB%" --disable-version-check
:end
pause
